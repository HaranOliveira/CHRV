<?php
//conexão com o banco de dados
$servidor='localhost';//local onde está hospedado o software
$usuario='root';//login do usuário
$senha='';//senha do usuário
$banco='chrv_bd';//nome do banco de dados
$charset='utf8';//linguagem utilizada
//incremento de segurança
$salt="#B0bsoMm/s1c4lc3nt&r6g";//código utilizado para ajudar na codificação da senha
?>
