<?php

  // Função para calculo de uma porcetagem
  function calculo_porcentagem ( $porcentagem, $total ) {
  return ( $porcentagem / 100 ) * $total;
  }

?>
